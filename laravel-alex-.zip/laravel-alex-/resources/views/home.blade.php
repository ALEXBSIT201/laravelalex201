@extends('layout.app')

@section('content')
<h1>You are on the Home Page</h1>
@endsection

@section('title')
   Home Page
@endsection
