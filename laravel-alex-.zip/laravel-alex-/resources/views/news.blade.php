@extends('layout.app')

@section('content')
<h1>You are on the News Page</h1>
@endsection

@section('title')
   News Page
@endsection
