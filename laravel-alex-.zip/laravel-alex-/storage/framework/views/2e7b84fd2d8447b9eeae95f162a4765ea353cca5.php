

<?php $__env->startSection('content'); ?>
<h1>You are on the Home Page</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
   Home Page
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-alex-\resources\views/home.blade.php ENDPATH**/ ?>