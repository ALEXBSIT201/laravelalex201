<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page</title>
</head>
<body>
    <header>
        <nav>
            <a href="">Landing Page</a>
            <a href="">Home</a>
            <a href="">Profile</a>
            <a href="">Events</a>
            <a href="">News</a>
        </nav>
    </header>
    <h1>Welcome to the Landing Page</h1>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel-alex-\resources\views/welcome.blade.php ENDPATH**/ ?>